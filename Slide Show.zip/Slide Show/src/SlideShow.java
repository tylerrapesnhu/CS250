import java.awt.BorderLayout;
import java.awt.CardLayout;
import java.awt.EventQueue;
import java.awt.FlowLayout;
import java.awt.HeadlessException;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.io.IOException;
import java.net.URI;
import java.util.Arrays;
import java.util.List;

import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import java.awt.Color;
import java.awt.Desktop;

public class SlideShow extends JFrame {

	//Initialize and Declare Variables created "southPane" to fix bug
	private JPanel slidePane = new JPanel();
	private JPanel textPane = new JPanel();
	private JPanel buttonPane = new JPanel();
	private JPanel southPane = new JPanel();
	private CardLayout card = new CardLayout();
	private CardLayout cardText = new CardLayout();
	private JButton btnPrev = new JButton();
	private JButton btnNext = new JButton();

	//replaced methods with slide objects for cleaner code
	private List<Slide> slides = Arrays.asList(
			new Slide(
					"<font size='5'>#1 Cal-a-Vie Health Spa</font> <br>A European-Style Spa & Wellness Retreat", 
					"/resources/slide1.jpeg", 
					"https://www.cal-a-vie.com/"),
			new Slide(
					"#2 Canyon Ranch Lenox</font> <br>New Beginnings in the Berkshires",
					"/resources/slide2.jpeg",
					"https://www.canyonranch.com/lenox/massachusetts-resort/"),
			new Slide(
					"#3 Mii Amo Spa</font> <br>A destination spa",
					"/resources/slide3.jpeg",
					"https://www.miiamo.com"),
			new Slide(
					"#4 KAMALAYA KOH SAMUI</font> <br>Wellness sanctuary and holistic spa",
					"/resources/slide4.jpeg",
					"https://kamalaya.com/"),
			new Slide(
					"#5 Rancho La Puerta</font> <br>A personalized experience",
					"/resources/slide5.jpeg",
					"https://rancholapuerta.com/")
	);
			
	/**
	 * Create the application.
	 */
	public SlideShow() throws HeadlessException {
		initComponent();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initComponent() {
		//Configure component/controls
		textPane.setBackground(Color.YELLOW);
		textPane.setBounds(5, 470, 790, 50);
		textPane.setVisible(true);
		southPane = new JPanel();
		southPane.setLayout(new BoxLayout(southPane, BoxLayout.Y_AXIS));

		//Setup frame attributes
		setSize(800, 600);
		setLocationRelativeTo(null);
		setTitle("Top 5 Destinations SlideShow");
		getContentPane().setLayout(new BorderLayout(10, 50));
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

		//Setting the layouts for the panels
		slidePane.setLayout(card);
		textPane.setLayout(cardText);
		
		//logic to add each of the slides and text
		slides.forEach(s -> {
			final JLabel imageLabel = new JLabel(s.getImage());
			imageLabel.addMouseListener(new MouseAdapter() {
				@Override
				public void mouseClicked(MouseEvent evt) {
					try {
						Desktop.getDesktop().browse(URI.create(s.getUrl()));
					} catch(IOException e) {
						e.printStackTrace();
					}
				}
			});
			slidePane.add(imageLabel);
			textPane.add(new JLabel(s.getDescription()));
			
		});
		

		getContentPane().add(slidePane, BorderLayout.CENTER);
		southPane.add(textPane);

		buttonPane.setLayout(new FlowLayout(FlowLayout.CENTER, 20, 10));

		//cleaned up goPrevious and goNext
		btnPrev.setText("Previous");
		btnPrev.addActionListener((ActionEvent e) -> goPrevious());
				
		buttonPane.add(btnPrev);

		btnNext.setText("Next");
		btnNext.addActionListener((ActionEvent e) -> goNext());
		buttonPane.add(btnNext);

		southPane.add(buttonPane);
		
		getContentPane().add(southPane, BorderLayout.SOUTH);
	}

	/**
	 * Previous Button Functionality
	 */
	private void goPrevious() {
		card.previous(slidePane);
		cardText.previous(textPane);
	}
	
	/**
	 * Next Button Functionality
	 */
	private void goNext() {
		card.next(slidePane);
		cardText.next(textPane);
	}
	
	/**
	 * Launch the application.
	 */
	//Cleaned code by making the program do one thing upon startup  
	public static void main(String[] args) {
		EventQueue.invokeLater(() -> (new SlideShow()).setVisible(true));
	}
	
	class Slide {
		private final String description;
		private final String image;
		private final String url;
		public Slide(final String description, final String image, final String url) {
			super();
			this.description = "<html><body>" + description + "</body></html>";
			this.image = "<html><body><img width= '800' height='500' src='" + getClass().getResource(image) + "'</body></html>";
			this.url = url;
		}
		public String getDescription() {
			return description;
		}
		public String getImage() {
			return image;
		}
		public String getUrl() {
			return url;
		}
		
		
		
		
	}
}